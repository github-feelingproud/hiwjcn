﻿using Lib.core;
using Lib.helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Lib.mvc
{
    public static class ResultHelper
    {
        public static ActionResult BadRequest(string msg)
        {
            return new CustomJsonResult()
            {
                Data = new ResJson() { success = false, msg = msg },
                JsonRequestBehavior = JsonRequestBehavior.AllowGet
            };
        }
    }

    /// <summary>
    /// json格式
    /// </summary>
    [Serializable]
    [DataContract]
    public class ResJson : ResultMsg
    {
        [DataMember]
        public virtual bool success
        {
            get { return this.Success; }
            set { this.Success = value; }
        }

        [DataMember]
        public virtual string msg
        {
            get { return this.ErrorMsg; }
            set { this.ErrorMsg = value; }
        }

        [DataMember]
        public virtual object data
        {
            get { return this.Data; }
            set { this.Data = value; }
        }

        [DataMember]
        public virtual string code
        {
            get { return this.ErrorCode; }
            set { this.ErrorCode = value; }
        }
    }

    /// <summary>
    /// 汽配龙的model
    /// </summary>
    [Serializable]
    [DataContract]
    public class ResultMsg
    {
        [DataMember]
        public string UserToken { get; set; }
        [DataMember]
        public string SafeCode { get; set; }
        [DataMember]
        public bool Success { get; set; }
        [DataMember]
        public string ErrorCode { get; set; }
        [DataMember]
        public string ErrorMsg { get; set; }
        [DataMember]
        public object Data { get; set; }
        [DataMember]
        public int Total { get; set; }

        [Obsolete("使用没有参数的构造函数")]
        public ResultMsg(object data, bool success, string errorCode, string errorMsg, string userToken)
        {
            this.Data = data;
            this.Success = success;
            this.ErrorMsg = errorMsg;
            this.ErrorCode = errorCode;
            this.UserToken = userToken;
        }

        [Obsolete("使用没有参数的构造函数")]
        public ResultMsg(bool success, string errorCode, string errorMsg, string userToken)
        {
            this.Success = success;
            this.ErrorMsg = errorMsg;
            this.ErrorCode = errorCode;
            this.UserToken = userToken;
        }

        [Obsolete("使用没有参数的构造函数")]
        public ResultMsg(bool success, string errorCode, string errorMsg)
        {
            this.Success = success;
            this.ErrorMsg = errorMsg;
            this.ErrorCode = errorCode;
        }

        public ResultMsg() { }
    }

    /// <summary>
    /// 解决mvc中json丢时区的问题
    /// </summary>
    public class CustomJsonResult : JsonResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            if (context == null)
            {
                throw new ArgumentNullException("context");
            }

            var response = context.HttpContext.Response;

            if (ValidateHelper.IsPlumpString(this.ContentType))
            {
                response.ContentType = this.ContentType;
            }
            else
            {
                response.ContentType = "application/json";
            }

            if (this.ContentEncoding != null)
            {
                response.ContentEncoding = this.ContentEncoding;
            }

            if (this.Data != null)
            {
                var json = JsonHelper.ObjectToJson(Data);
                response.Write(json);
            }
        }
    }

    public class LoginResult : ActionResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            string url = ConvertHelper.GetString(context.HttpContext.Request.Url);
            url = EncodingHelper.UrlEncode(url);
            context.HttpContext.Response.Redirect("/account/login/?next=" + url);
            context.HttpContext.ApplicationInstance.CompleteRequest();
        }
    }
    public class GoHomeResult : ActionResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.Redirect("/page/home/");
            context.HttpContext.ApplicationInstance.CompleteRequest();
        }
    }
    /// <summary>
    /// 301永久跳转
    /// </summary>
    public class Http301 : ActionResult
    {
        public string Url { get; set; }

        public Http301(string url)
        {
            this.Url = url;
        }

        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.Clear();
            context.HttpContext.Response.BufferOutput = true;
            context.HttpContext.Response.Status = "301 Moved Permanently";
            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.MovedPermanently;
            context.HttpContext.Response.RedirectLocation = this.Url;
            //context.HttpContext.Response.End();
            context.HttpContext.ApplicationInstance.CompleteRequest();
        }
    }

    public class Http403 : ActionResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.Clear();
            context.HttpContext.Response.BufferOutput = true;
            context.HttpContext.Response.StatusDescription = "Forbidden";
            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.Forbidden;
            context.HttpContext.Server.Transfer("~/ErrorPage/403.html");
            //context.HttpContext.Response.End();
            context.HttpContext.ApplicationInstance.CompleteRequest();
        }
    }
    public class Http404 : ActionResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.Clear();
            context.HttpContext.Response.BufferOutput = true;
            context.HttpContext.Response.StatusDescription = "404 Not Found";
            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.NotFound;
            context.HttpContext.Server.Transfer("~/ErrorPage/404.html");
            //context.HttpContext.Response.End();
            context.HttpContext.ApplicationInstance.CompleteRequest();
        }
    }
    public class Http500 : ActionResult
    {
        public override void ExecuteResult(ControllerContext context)
        {
            context.HttpContext.Response.Clear();
            context.HttpContext.Response.BufferOutput = true;
            context.HttpContext.Response.StatusDescription = "Internal Server Error";
            context.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            context.HttpContext.Server.Transfer("~/ErrorPage/500.html");
            //context.HttpContext.Response.End();
            context.HttpContext.ApplicationInstance.CompleteRequest();
        }
    }
}
